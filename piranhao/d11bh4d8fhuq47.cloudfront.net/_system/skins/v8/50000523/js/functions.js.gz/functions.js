
  function build_menu() {
  
    if( !$('menuId') ) {
    
      $$('#menuzone ul.menu')[0].setAttribute('id', 'menuId');
  		  
    	 $$('#menuzone ul.menu ul.level1').each(function(level1) {          
         li = level1.getElementsBySelector("li ul.level2 li");          
         for (i = 0; i < li.length; i++)
         {
           level1.appendChild(li[i]);
         }          
       });     
    
    	 Menu.init("menuId", {"orientation": Menu.HORIZONTAL, "hidePause": 0.2});
    	
    	 var sirka = 0;
    	 var vyska = 0;
       $$('#menuzone ul.menu li').each(function(item) {       
         if (item.parentNode.hasClassName('menu')) {
           sirka = sirka + item.offsetWidth; 
           vyska = item.offsetHeight;
           if( vyska > 50 ) item.style.display = 'none';     
           if( sirka > 770 ) item.style.display = 'none'; 
         }           
       }
       );
    
    }
  
  }
  
  function navigator_clear() {
  
    var navi = document.getElementById('pageNavigator');
    var lang = document.getElementById('languageSelect');          
    
    if( navi.innerHTML == "" && lang.innerHTML == "" ) {              
      $('pageNavigator').style.display = 'none';
      $('languageSelect').style.display = 'none';              
    }  
  
  }
  
  
  function setContentSize()  { 
                                                                                                                                                         
    var content = document.getElementById('content');
    var siteHeight = (document.getElementById('body_bg') ? document.getElementById('body_bg').offsetHeight : 0); 
    var headerHeight = (document.getElementById('header') ? document.getElementById('header').offsetHeight : 0);                                                                                               
    var footerHeight = (document.getElementById('footer') ? document.getElementById('footer').offsetHeight : 0);                                
    var menuHeight = (document.getElementById('menuzone') ? document.getElementById('menuzone').offsetHeight : 0);                 
    var navigatorHeight = (document.getElementById('navizone') ? document.getElementById('navizone').offsetHeight : 0);            
   
    var webPage = content.offsetHeight + headerHeight + footerHeight + menuHeight + navigatorHeight;
   
    var windowHeight = 0;

    if (window.innerHeight)
    {
       windowHeight = window.innerHeight;
    }
    else
    {
       windowHeight = document.documentElement.clientHeight;
    }
    
    if (webPage < windowHeight)
    {
       content.style.height = windowHeight - headerHeight - footerHeight - menuHeight - navigatorHeight - 28 + 'px';    
    }
  
  }


